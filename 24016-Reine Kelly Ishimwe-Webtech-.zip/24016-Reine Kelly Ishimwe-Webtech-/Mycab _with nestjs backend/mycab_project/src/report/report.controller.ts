import { Controller } from '@nestjs/common';

@Controller('report')
export class ReportController {}
